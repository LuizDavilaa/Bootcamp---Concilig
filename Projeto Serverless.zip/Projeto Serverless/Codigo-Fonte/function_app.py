import csv
import io
import json
import logging
import os
import time

import azure.functions as func
from azure.communication.email import EmailClient
from azure.core.exceptions import ResourceExistsError
from azure.data.tables import TableServiceClient

app = func.FunctionApp()

TABLE_NAME = "candidatosnotificados"
TABLE_DOCUMENTOS = "documentosadmissionais"
LINK_PADRAO = "https://forms.office.com/exemplo-solicitacao-documentos"

CAMPOS_OBRIGATORIOS = [
    "nomeCompleto",
    "cpf",
    "rg",
    "dataNascimento",
    "nomeMae",
    "carteiraTrabalho",
    "telefone",
    "email",
]


def _get_table_client(table_name: str = TABLE_NAME):
    conn_str = os.environ["AzureWebJobsStorage"]
    service = TableServiceClient.from_connection_string(conn_str)
    try:
        service.create_table(table_name)
    except ResourceExistsError:
        pass
    return service.get_table_client(table_name)


def _ja_notificado(table_client, email: str) -> bool:
    try:
        table_client.get_entity(partition_key="candidato", row_key=email.lower())
        return True
    except Exception:
        return False


def _marcar_notificado(table_client, email: str, nome: str, cargo: str):
    table_client.upsert_entity({
        "PartitionKey": "candidato",
        "RowKey": email.lower(),
        "nome": nome,
        "cargo": cargo,
        "enviado_em": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    })


def _montar_corpo_email(nome: str, cargo: str, link_documentos: str) -> str:
    return (
        f"Olá, {nome}!\n\n"
        f"Temos uma ótima notícia: você foi aprovado(a) para a vaga de {cargo} na Concilig!\n\n"
        f"Nossa equipe de Recursos Humanos gostaria de dar continuidade ao seu processo de "
        f"admissão o quanto antes. Para isso, precisamos que você envie alguns documentos "
        f"através do link abaixo:\n\n"
        f"{link_documentos}\n\n"
        f"Fique atento(a): assim que recebermos seus documentos, entraremos em contato para "
        f"alinhar os próximos passos e sua data de início.\n\n"
        f"Seja bem-vindo(a) à equipe Concilig!\n\n"
        f"Atenciosamente,\nEquipe de Recursos Humanos - Concilig"
    )


def _enviar_email(destinatario: str, nome: str, cargo: str) -> bool:
    conn_str = os.environ.get("ACS_CONNECTION_STRING")
    remetente = os.environ.get("ACS_SENDER_EMAIL")
    link_documentos = os.environ.get("LINK_SOLICITACAO_DOCUMENTOS", LINK_PADRAO)

    if not conn_str or not remetente:
        logging.warning(
            "ACS_CONNECTION_STRING ou ACS_SENDER_EMAIL não configurados; e-mail não enviado."
        )
        return False

    corpo = _montar_corpo_email(nome, cargo, link_documentos)

    mensagem = {
        "senderAddress": remetente,
        "recipients": {"to": [{"address": destinatario, "displayName": nome}]},
        "content": {
            "subject": "Concilig - Você foi aprovado! Próximos passos da admissão",
            "plainText": corpo,
        },
    }

    try:
        client = EmailClient.from_connection_string(conn_str)
        poller = client.begin_send(mensagem)
        resultado = poller.result()
        return resultado["status"] == "Succeeded"
    except Exception:
        logging.exception(f"Falha ao enviar e-mail para {destinatario}")
        return False


@app.blob_trigger(
    arg_name="myblob",
    path="input-csv/{name}",
    connection="AzureWebJobsStorage",
)
def notifica_upload_csv(myblob: func.InputStream):
    logging.info(
        f"Novo arquivo detectado: {myblob.name} ({round(myblob.length / 1024, 2)} KB)"
    )

    conteudo = myblob.read().decode("utf-8-sig")
    leitor = csv.DictReader(io.StringIO(conteudo))

    table_client = _get_table_client()

    total = 0
    enviados = 0
    ignorados_duplicados = 0
    falhas = 0

    for linha in leitor:
        total += 1
        nome = (linha.get("nome") or "").strip()
        email = (linha.get("email") or "").strip()
        cargo = (linha.get("cargo") or "").strip()

        if not email:
            logging.warning(f"Linha {total} sem e-mail, ignorada: {linha}")
            continue

        if _ja_notificado(table_client, email):
            ignorados_duplicados += 1
            logging.info(f"Candidato {email} já havia recebido o e-mail. Ignorado.")
            continue

        if _enviar_email(email, nome, cargo):
            _marcar_notificado(table_client, email, nome, cargo)
            enviados += 1
            logging.info(f"E-mail enviado para {nome} <{email}> (vaga: {cargo}).")
        else:
            falhas += 1

    logging.info(
        f"Processamento concluído: {total} candidatos, {enviados} e-mails enviados, "
        f"{ignorados_duplicados} ignorados (duplicados), {falhas} falhas."
    )


@app.route(route="documentos", methods=["POST"], auth_level=func.AuthLevel.ANONYMOUS)
def receber_documentos(req: func.HttpRequest) -> func.HttpResponse:
    try:
        dados = req.get_json()
    except ValueError:
        return _resposta_json({"ok": False, "erro": "Corpo da requisição não é um JSON válido."}, 400)

    faltando = [campo for campo in CAMPOS_OBRIGATORIOS if not str(dados.get(campo, "")).strip()]
    if faltando:
        return _resposta_json(
            {"ok": False, "erro": f"Campos obrigatórios ausentes: {', '.join(faltando)}"}, 400
        )

    cpf = "".join(filter(str.isdigit, str(dados.get("cpf", ""))))
    email = str(dados.get("email", "")).strip().lower()

    entidade = {
        "PartitionKey": "candidato",
        "RowKey": cpf,
        "nomeCompleto": str(dados.get("nomeCompleto", "")).strip(),
        "cpf": cpf,
        "rg": str(dados.get("rg", "")).strip(),
        "orgaoEmissorRg": str(dados.get("orgaoEmissorRg", "")).strip(),
        "dataNascimento": str(dados.get("dataNascimento", "")).strip(),
        "estadoCivil": str(dados.get("estadoCivil", "")).strip(),
        "nomeMae": str(dados.get("nomeMae", "")).strip(),
        "carteiraTrabalho": str(dados.get("carteiraTrabalho", "")).strip(),
        "serieUfCtps": str(dados.get("serieUfCtps", "")).strip(),
        "pisPasep": str(dados.get("pisPasep", "")).strip(),
        "cep": str(dados.get("cep", "")).strip(),
        "endereco": str(dados.get("endereco", "")).strip(),
        "bairro": str(dados.get("bairro", "")).strip(),
        "cidade": str(dados.get("cidade", "")).strip(),
        "uf": str(dados.get("uf", "")).strip(),
        "telefone": str(dados.get("telefone", "")).strip(),
        "email": email,
        "banco": str(dados.get("banco", "")).strip(),
        "agencia": str(dados.get("agencia", "")).strip(),
        "conta": str(dados.get("conta", "")).strip(),
        "recebido_em": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }

    try:
        table_client = _get_table_client(TABLE_DOCUMENTOS)
        table_client.upsert_entity(entidade)
    except Exception:
        logging.exception("Falha ao salvar dados do candidato na tabela.")
        return _resposta_json({"ok": False, "erro": "Falha interna ao salvar os dados."}, 500)

    logging.info(f"Documentos recebidos de {entidade['nomeCompleto']} (CPF {cpf}).")
    return _resposta_json({"ok": True, "mensagem": "Dados recebidos com sucesso."}, 200)


def _resposta_json(corpo: dict, status_code: int) -> func.HttpResponse:
    return func.HttpResponse(
        json.dumps(corpo, ensure_ascii=False),
        status_code=status_code,
        mimetype="application/json",
    )
