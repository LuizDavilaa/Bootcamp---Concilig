# Script de deploy - cria os recursos no Azure e publica a Function via zip deploy remoto
# Nao exige Azure Functions Core Tools instalado localmente (usa build remoto/Oryx).
# Inclui: Storage + BlobTrigger + Table Storage (dedupe), Azure Communication Services
# (envio de e-mail), Function HTTP para receber dados do formulario e o site estatico
# do formulario hospedado na propria Storage Account.

$ErrorActionPreference = "Stop"

# --- Ajuste esses valores se quiser ---
$LOCATION       = "brazilsouth"
$RESOURCE_GROUP = "rg-blobtrigger-tcc"
$STORAGE_NAME   = "stblobtriggertcc$(Get-Random -Minimum 1000 -Maximum 9999)"
$FUNCTION_APP   = "func-blobtrigger-tcc-$(Get-Random -Minimum 1000 -Maximum 9999)"
$ACS_NAME       = "acs-blobtrigger-tcc"
$EMAIL_SVC_NAME = "email-blobtrigger-tcc"
$CONTAINER_NAME = "input-csv"
# ----------------------------------------

Write-Host "1) Login no Azure..." -ForegroundColor Cyan
az login

Write-Host "2) Criando resource group '$RESOURCE_GROUP'..." -ForegroundColor Cyan
az group create --name $RESOURCE_GROUP --location $LOCATION

Write-Host "3) Criando storage account '$STORAGE_NAME'..." -ForegroundColor Cyan
az storage account create `
  --name $STORAGE_NAME `
  --resource-group $RESOURCE_GROUP `
  --location $LOCATION `
  --sku Standard_LRS

Write-Host "4) Criando container '$CONTAINER_NAME'..." -ForegroundColor Cyan
$connString = az storage account show-connection-string `
  --name $STORAGE_NAME `
  --resource-group $RESOURCE_GROUP `
  --query connectionString -o tsv

az storage container create `
  --name $CONTAINER_NAME `
  --connection-string $connString

Write-Host "5) Habilitando site estatico (formulario) na Storage Account..." -ForegroundColor Cyan
az storage blob service-properties update `
  --account-name $STORAGE_NAME `
  --static-website --index-document "index.html" --404-document "index.html"

az storage blob upload `
  --connection-string $connString `
  --container-name '$web' `
  --name "index.html" `
  --file (Join-Path $PSScriptRoot "site\index.html") `
  --content-type "text/html" `
  --overwrite

$siteUrl = az storage account show --name $STORAGE_NAME --resource-group $RESOURCE_GROUP --query "primaryEndpoints.web" -o tsv
Write-Host "   Site do formulario: $siteUrl"

Write-Host "6) Criando Azure Communication Services + Email (dominio gerenciado)..." -ForegroundColor Cyan
az communication create --name $ACS_NAME --resource-group $RESOURCE_GROUP --location "global" --data-location "Brazil"
az communication email create --name $EMAIL_SVC_NAME --resource-group $RESOURCE_GROUP --location "global" --data-location "Brazil"
az communication email domain create --domain-name "AzureManagedDomain" --email-service-name $EMAIL_SVC_NAME --resource-group $RESOURCE_GROUP --location "global" --domain-management "AzureManaged"

$domainId = "/subscriptions/$(az account show --query id -o tsv)/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.Communication/emailServices/$EMAIL_SVC_NAME/domains/AzureManagedDomain"
az communication update --name $ACS_NAME --resource-group $RESOURCE_GROUP --linked-domains $domainId

$mailFromDomain = az communication email domain show --domain-name "AzureManagedDomain" --email-service-name $EMAIL_SVC_NAME --resource-group $RESOURCE_GROUP --query "mailFromSenderDomain" -o tsv
$acsSender = "DoNotReply@$mailFromDomain"
$acsConnString = az communication list-key --name $ACS_NAME --resource-group $RESOURCE_GROUP --query primaryConnectionString -o tsv
Write-Host "   Remetente: $acsSender"

Write-Host "7) Criando Function App '$FUNCTION_APP' (Linux, Consumption, Python 3.11)..." -ForegroundColor Cyan
az functionapp create `
  --resource-group $RESOURCE_GROUP `
  --consumption-plan-location $LOCATION `
  --runtime python `
  --runtime-version 3.11 `
  --functions-version 4 `
  --name $FUNCTION_APP `
  --storage-account $STORAGE_NAME `
  --os-type Linux

Write-Host "8) Configurando app settings (ACS + link do formulario)..." -ForegroundColor Cyan
az functionapp config appsettings set `
  --name $FUNCTION_APP `
  --resource-group $RESOURCE_GROUP `
  --settings "ACS_CONNECTION_STRING=$acsConnString" "ACS_SENDER_EMAIL=$acsSender" "LINK_SOLICITACAO_DOCUMENTOS=$siteUrl"

Write-Host "9) Habilitando CORS na Function App para o site do formulario..." -ForegroundColor Cyan
az functionapp cors add --name $FUNCTION_APP --resource-group $RESOURCE_GROUP --allowed-origins $siteUrl.TrimEnd('/')

Write-Host "10) Empacotando o codigo..." -ForegroundColor Cyan
$zipPath = Join-Path $PSScriptRoot "function.zip"
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Compress-Archive -Path (Join-Path $PSScriptRoot "function_app.py"), `
                        (Join-Path $PSScriptRoot "host.json"), `
                        (Join-Path $PSScriptRoot "requirements.txt") `
                  -DestinationPath $zipPath

Write-Host "11) Publicando via zip deploy (com build remoto)..." -ForegroundColor Cyan
az functionapp deployment source config-zip `
  --resource-group $RESOURCE_GROUP `
  --name $FUNCTION_APP `
  --src $zipPath `
  --build-remote true

Write-Host ""
Write-Host "=== Deploy concluido ===" -ForegroundColor Green
Write-Host "Function App: $FUNCTION_APP"
Write-Host "Storage Account: $STORAGE_NAME"
Write-Host "Container monitorado: $CONTAINER_NAME"
Write-Host "Site do formulario: $siteUrl"
Write-Host ""
Write-Host "Para testar o BlobTrigger, envie um CSV para o container:"
Write-Host "  az storage blob upload --connection-string `"<connection-string>`" --container-name $CONTAINER_NAME --name teste.csv --file .\teste.csv"
Write-Host ""
Write-Host "Para testar o formulario, abra $siteUrl no navegador e preencha os dados."
