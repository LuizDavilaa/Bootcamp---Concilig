# Automação de Admissão - Concilig (Azure Serverless)

Automação completa em nuvem para o RH da Concilig: o RH sobe uma planilha de
candidatos aprovados, cada um recebe automaticamente um e-mail com o link de
um formulário de solicitação de documentos admissionais, e os dados enviados
por eles ficam registrados numa tabela — tudo dentro do Azure.

## Como funciona (fluxo completo)

1. RH sobe um CSV (`nome,email,cargo`) no container `input-csv` do Blob
   Storage.
2. Isso dispara a Function `notifica_upload_csv` (**BlobTrigger**), que lê o
   CSV linha a linha.
3. Para cada candidato ainda não notificado (controle via **Azure Table
   Storage**, tabela `candidatosnotificados`), a Function envia um e-mail via
   **Azure Communication Services (Email)** com o link do formulário de
   documentos.
4. O candidato abre o link, preenche o formulário (site estático hospedado
   direto na Storage Account) e envia.
5. O formulário chama a Function HTTP `receber_documentos`, que salva os
   dados na tabela `documentosadmissionais`.

## Componentes técnicos

| Componente | Serviço Azure |
|---|---|
| Armazenamento da planilha | Blob Storage (container `input-csv`) |
| Gatilho + leitura da planilha | Azure Functions (Python, BlobTrigger) |
| Envio de e-mail | Azure Communication Services - Email (domínio gerenciado, sem custo/config externa) |
| Controle de duplicidade de envio | Azure Table Storage (`candidatosnotificados`) |
| Formulário de documentos | Site estático na própria Storage Account (`$web`) |
| Recebimento dos dados do formulário | Azure Functions (Python, HTTP Trigger) |
| Armazenamento dos dados recebidos | Azure Table Storage (`documentosadmissionais`) |

## Estrutura do projeto

- `function_app.py` — as duas Functions: `notifica_upload_csv` (BlobTrigger)
  e `receber_documentos` (HTTP)
- `host.json` — configuração do host do Functions runtime
- `requirements.txt` — dependências Python (`azure-functions`,
  `azure-data-tables`, `azure-communication-email`)
- `site/index.html` — página do formulário (HTML/CSS/JS puro, sem framework)
- `local.settings.json` — configurações locais (não versionar; contém
  connection strings)
- `deploy.ps1` — script que recria todo o ambiente do zero
- `teste.csv` / `teste_e2e.csv` — planilhas de exemplo para teste

## Deploy no Azure

Ver `deploy.ps1` — cria resource group, storage account, container
`input-csv`, site estático do formulário, Azure Communication Services
(com domínio de e-mail gerenciado), Function App e publica o código, tudo
via Azure CLI (sem precisar de Azure Functions Core Tools instalado
localmente — usa build remoto/Oryx com `--build-remote true`).

## Testando

**Fluxo de e-mail (BlobTrigger):**
1. Suba um `.csv` (`nome,email,cargo`) no container `input-csv`.
2. Aguarde de 1 a 3 minutos (o BlobTrigger clássico do Consumption Plan
   detecta por varredura periódica, não é instantâneo).
3. Confira a caixa de entrada do e-mail informado na planilha.
4. Confirme na tabela `candidatosnotificados` que o envio foi registrado.

**Fluxo do formulário:**
1. Abra a URL do site estático (ex.:
   `https://stblobtriggertcc6260.z15.web.core.windows.net/`) no navegador.
2. Preencha os campos e envie.
3. Confirme na tabela `documentosadmissionais` que os dados chegaram.

## Recursos provisionados (ambiente de teste)

- Resource Group: `rg-blobtrigger-tcc` — Brazil South
- Storage Account: `stblobtriggertcc6260` (container `input-csv`, site
  estático em `$web`)
- Function App: `func-blobtrigger-tcc-5609` (Linux, Consumption, Python 3.11)
- Azure Communication Services: `acs-blobtrigger-tcc`
- Email Communication Service: `email-blobtrigger-tcc` (domínio gerenciado)

## Evidências de funcionamento

- Upload de CSV → e-mail enviado com sucesso e registrado em
  `candidatosnotificados` (confirmado via `az storage entity query`).
- Reenvio do mesmo CSV → segunda execução corretamente **ignorada por
  duplicidade** (não manda e-mail de novo para quem já recebeu).
- Formulário testado ponta a ponta: envio via `fetch()` no navegador (com
  CORS liberado só para o domínio do site) → Function HTTP → dados
  gravados em `documentosadmissionais`, com todos os campos corretos.

Isso comprova o fluxo completo descrito na proposta do grupo: upload da
planilha → notificação individual por e-mail → coleta dos dados admissionais
do candidato, sem intervenção manual do RH.
